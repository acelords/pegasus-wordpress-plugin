=== AceLords Project Pegasus WordPress Plugins ===
Contributors: acelords
Donate link: https://ko-fi.com/acelords
Tags: acelords,pegasus,plugins
Requires at least: 4.7
Tested up to: 5.5
Stable tag: 1.1.9
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

WordPress Plugins for complementing AceLords' Project Pegasus

== Description ==

AceLords Pegasus is a complete and complex freelancing-centered system aimed at
complementing AceLords' Project Pegasus
WordPress Plugins for complementing AceLords' Project Pegasus

Available Plugins:
* OceanWP Home Order Form
* Pricing Widget

== Frequently Asked Questions ==
- Does this work on non-AceLords Pegasus projects?
Unfortunately, no. To use this plugin, you must be subscribed to the AceLords Project Pegasus
Freelance System.

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

1. Admin Page View of all plugins

== Changelog ==

= 1.1.6 =
* Added Pricing (TailWind) Plugin

= 1.1.1 =
* Security Updates

= 1.0.5 =
* Added Pricing Table

= 1.0.0 =
* Added OceanWP Home Page Order Widget

== Upgrade Notice ==

= 1.0.5 =
2 plugins and counting!

= 1.0.0 =
This version fixes a security related bug.  Upgrade immediately.
