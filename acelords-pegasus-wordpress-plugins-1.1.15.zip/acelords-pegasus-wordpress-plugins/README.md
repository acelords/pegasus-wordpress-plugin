# AceLords Pegasus WordPress Plugin
AceLords plugin to complement AceLords' project pegasus project.

## Contributing
- [AceLords](https://www.acelords.space)

## License
- AceLords Proprietary License

# Changelog 
### 1.1.15
* Refactored plugin updater method

### 1.1.6
* Added Pricing (TailWind) Plugin

### 1.1.1
* Security Updates

### 1.0.5
* Added Pricing Table

### 1.0.0
* Added OceanWP Home Page Order Widget

## Contributing
- [AceLords](https://acelords.space)
